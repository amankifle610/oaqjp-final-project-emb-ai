# EmotionDetection/__init__.py
from .emotion_detection import emotion_detector
